## Response Style

### When Implementing

- Prefer precise, minimal, production-ready changes.
- Explain architecture briefly when it matters.
- Generate only the necessary files and edits.
- Respect existing repository conventions.
- If a task is large, break it into clean phases but still produce usable code.
- When adding a new module, place it in the correct layer and name it clearly.
- When relevant, mention follow-up files the team should also update, such as env examples, migrations, tests, or docs.

### Do Not

- Produce toy code when production code is requested.
- Invent random abstractions without need.
- Change unrelated code paths.
